
<?php $__env->startSection('content'); ?>
<div class="carousel slide carousel-fade mt-2" id="home-slide">
    <ol class="carousel-indicators">
        <li data-target="#home-slide" class="update active" data-slide-to="0"></li>
        <li data-target="#home-slide" class="update" data-slide-to="1"></li>
        <li data-target="#home-slide" class="update" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active" data-interval="3000">
            <img style="height:350px;" src="public/images/Layer 6.jpg" alt="" class="d-block w-100" />
        </div>
        <div class="carousel-item" data-interval="3000">
            <img style="height:350px;" src="public/images/Layer 3.jpg" alt="" class="d-block w-100" />
        </div>
        <div class="carousel-item" data-interval="3000">
            <img style="height:350px;" src="public/images/Layer 4.jpg" alt="" class="d-block w-100" />
        </div>
    </div>
</div>
<?php if(session()->has('status')): ?>
<div class="alert alert-success text-center">
    <i class="bi bi-check-circle" style="font-size:35px;"></i><?php echo e(session()->get('status')); ?>

</div>
<?php endif; ?>
<div class="owl-carousel owl-theme my-2">
    <?php $__currentLoopData = $hangsanxuat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item">
        <div class="box">
            <a href="" class="box-item"><?php echo e($value->tenhang); ?></a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div id="sidebar">
    <div class="sidebar-left">
        <div class="wp-product-light">
            <div class="product-light"><span>Sản phẩm mới</span></div>
            <ul class="list-product">
                <?php $__currentLoopData = $sanphammoi->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="product-item">
                    <a href="" class="product-thumb">
                        <img src="<?php echo e(url($value->hinhanh)); ?>" alt="" />
                    </a>
                    <a href="" class="product-name">
                        <p><?php echo e($value->tensanpham); ?></p>
                    </a>
                    <div class="price">Giá bán: <span><?php echo e(number_format($value->dongia,0,'.','.')); ?>đ</span></div>
                    <a href="<?php echo e(route('themgiohang',$value->tensanpham_slug)); ?>" class="add-cart">Thêm giỏ hàng</a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="wp-product-light">
            <div class="product-light"><span>Sản phẩm</span></div>
            <?php echo $sanpham->links(); ?>

            <ul class="list-product">
                <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="product-item">
                    <a href="" class="product-thumb">
                        <img src="<?php echo e(url($value->hinhanh)); ?>" alt="" />
                    </a>
                    <a href="" class="product-name">
                        <p><?php echo e($value->tensanpham); ?></p>
                    </a>
                    <div class="price">Giá bán: <span><?php echo e(number_format($value->dongia,0,'.','.')); ?>đ</span></div>
                    <a href="<?php echo e(route('themgiohang',$value->tensanpham_slug)); ?>" class="add-cart">Thêm giỏ hàng</a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
    </div>
    <div class="sidebar-right">
        <a href="" class="layer-8">
            <img src="public/images/Layer 8.png" alt="" />
        </a>
        <a href="" class="layer-9">
            <img src="public/images/Layer 9.png" alt="" />
        </a>
        <a href="" class="layer-10">
            <img src="public/images/Layer 10.png" alt="" />
        </a>
        <a href="" class="layer-11">
            <img src="public/images/Layer 11.png" alt="" />
        </a>
        <a href="" class="layer-12">
            <img src="public/images/Layer 12.png" alt="" />
        </a>
        <a href="" class="layer-13">
            <img src="public/images/Layer 13.png" alt="" />
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaptopStore\resources\views/frontend/trangchu.blade.php ENDPATH**/ ?>