
<?php $__env->startSection('content'); ?>
<div id="sidebar-payment">
    <div class="sidebar-left">
        <form action="<?php echo e(route('khachhang.dathang')); ?>" class="payment" method="post">
            <?php echo csrf_field(); ?>
            <div class="group">
                <label for="">Số điện thoại <span>*</span></label>
                <input class="form-control <?php $__errorArgs = ['dienthoaigiaohang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="dienthoaigiaohang">
                <?php $__errorArgs = ['dienthoaigiaohang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback "><strong><?php echo e($message); ?></strong></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="group">
                <label for="">Địa chỉ nhận hàng <span>*</span></label>
                <input class="form-control <?php $__errorArgs = ['diachigiaohang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="diachigiaohang" name="diachigiaohang">
                <?php $__errorArgs = ['diachigiaohang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><strong><?php echo e($message); ?></strong></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="action">
                <button type="submit" class="btn btn-success mt-3">Đặt hàng</button>
            </div>
        </form>
    </div>
    <div class="sidebar-right">
        <div class="your-cart">Thanh toán</div>
        <table class="table">
            <thead class="thead-light">
                <tr class="text-center">
                    <th scope="col">Tên sản phẩm</th>
                    <th scope="col">Hình ảnh</th>
                    <th scope="col">Đơn giá</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($row->name); ?></td>
                    <td><img src="<?php echo e(url($row->options->image)); ?>" alt="" style="width:80px;"></td>
                    <td><?php echo e(number_format($row->price,0,'.','.')); ?>đ</td>
                    <td style="width:100px;"><?php echo e($row->qty); ?></td>
                    <td style="width:115px;"><?php echo e($row->subtotal()); ?>đ</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <div id="total">
            <span>Tổng tiền:</span><?php echo e(Cart::priceTotal()); ?>đ
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaptopStore\resources\views/frontend/thanhtoan.blade.php ENDPATH**/ ?>