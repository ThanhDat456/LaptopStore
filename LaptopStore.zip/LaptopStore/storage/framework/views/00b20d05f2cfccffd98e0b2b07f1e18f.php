
<?php $__env->startSection('content'); ?>
<div id="sidebar-cart">
    <?php if(session('status')): ?>
    <div class="alert alert-success text-center">
    <i class="bi bi-check-circle" style="font-size:35px;"></i><?php echo e(session()->get('status')); ?>

    </div>
    <?php endif; ?>
    <div class="your-cart mt-3">Giỏ hàng của bạn</div>
    <form action="<?php echo e(route('giohang.capnhat')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php if(Cart::count() > 0): ?>
        <table class="table table-hover">
            <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Tên sản phẩm</th>
                    <th scope="col">Hình ảnh</th>
                    <th scope="col">Đơn giá</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Thành tiền</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($row->name); ?></td>
                    <td><img style="width:50px;" src="<?php echo e(url($row->options->image)); ?>" alt=""></td>
                    <td><?php echo e(number_format($row->price,0,'.','.')); ?>đ</td>
                    <td>
                        <a href="<?php echo e(route('giohang.giam',['rowId'=>$row->rowId])); ?>" class="mins"><i class="bi bi-dash"></i></a>
                        <input type="text" class="qty" name="qty[<?php echo e($row->rowId); ?>]" value="<?php echo e($row->qty); ?>">
                        <a href="<?php echo e(route('giohang.tang',['rowId'=>$row->rowId])); ?>" class="plus"><i class="bi bi-plus-lg"></i></a>
                    </td>
                    <td><?php echo e(number_format($row->subtotal,0,'.','.')); ?>đ</td>
                    <td class="text-center">
                        <a href="<?php echo e(route('giohang.xoa',['rowId' => $row->rowId])); ?>" class="delete-cart">Xóa</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-cart mb-3" style="height:220px;border:1px solid #ddd;display:grid;place-items:center;border-radius:10px;">
            <i class="bi bi-basket3" style="font-size: 75px;margin-right: 15px;color: #c88383;"></i><span style="color:#000;font-weight:500">Không có sản phẩm trong giỏ hàng!</span>
        </div>
        <?php endif; ?>
        <div class="total text-right my-3">
            <span style="font-weight:600;padding-right:10px;">Tổng tiền:</span><?php echo e(Cart::priceTotal()); ?>đ
        </div>
        <div class="action">
            <button type="button" class="btn btn-danger"><a href="<?php echo e(route('giohang.tatca')); ?>" style="color:#ffffff;text-decoration:none;">Xóa tất cả</a></button>
            <button type="submit" class="btn btn-secondary" name="capnhat"><a style="color:#ffffff;text-decoration:none;">Cập nhật</a></button>
            <button type="button" class="btn btn-primary"><a href="<?php echo e(route('thanhtoan')); ?>" style="color:#ffffff;text-decoration:none;">Thanh toán</a></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaptopStore\resources\views/frontend/giohang.blade.php ENDPATH**/ ?>