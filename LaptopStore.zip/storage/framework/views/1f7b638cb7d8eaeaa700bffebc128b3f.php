
<?php $__env->startSection('content'); ?>
<div class="row text-center my-3">
    <div class="col-md-3 p-0">
        <div class="card bg-info" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title text-light">Doanh số</h5>
                <p class="card-text text-light"><?php echo e($count[1]); ?>0.000 VND</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 p-0">
        <div class="card bg-danger" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title text-light">khách hàng</h5>
                <p class="card-text text-light"><?php echo e($count[0]); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 p-0">
        <div class="card bg-warning" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title text-light">Đơn hàng đang xử lý</h5>
                <p class="card-text text-light"><?php echo e($count[2]); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 p-0">
        <div class="card bg-success" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title text-light">Đơn hàng thành công </h5>
                <p class="card-text text-light"><?php echo e($count[3]); ?></p>
            </div>
        </div>
    </div>
</div>
<div class="row my-3">
    <div class="col-md-12">
        <div class="card">
            <?php if(session('status')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card-head text-center">
                        <h5 class="mt-3">Đơn hàng mới</h5>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr class="text-center">
                            <th scope="col">#</th>
                            <th scope="col">Khách hàng</th>
                            <th scope="col">Số điện thoại giao hàng</th>
                            <th scope="col">Địa chỉ giao hàng</th>
                            <th scope="col">Thông tin đơn hàng</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Ngày đặt hàng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($donhang->count() >0): ?>
                        <?php $__currentLoopData = $donhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td scope="row"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($value->User->name); ?></td>
                            <td style="width:200px;"><?php echo e($value->dienthoaigiaohang); ?></td>
                            <td><?php echo e($value->diachigiaohang); ?></td>
                            <td>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr class="text-center">
                                            <th scope="col">#</th>
                                            <th scope="col">Sản phẩm</th>
                                            <th scope="col">Hình ảnh</th>
                                            <th scope="col">Số lượng</th>
                                            <th scope="col">Đơn giá</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $tempp = 0
                                        ?>
                                        <?php $__currentLoopData = $donhang_chitiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->donhang_id == $value->id): ?>
                                        <?php
                                        $tempp++
                                        ?>
                                        <tr class="text-center">
                                            <td scope="row"><?php echo e($tempp); ?></td>
                                            <td style="width:315px;"><?php echo e($item->SanPham->tensanpham); ?></td>
                                            <td><img src="<?php echo e(url($item->SanPham->hinhanh)); ?>" style="width:50px;" alt=""></td>
                                            <td><?php echo e($item->soluongban); ?></td>
                                            <td><?php echo e(number_format($item->dongiaban,0,'.','.')); ?>đ</td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <p style="font-weight:600;margin:0;">Tổng tiền:<span style="padding-left:20px;"><?php echo e($value->tongtien); ?>đ</span></p>
                            </td>
                            <?php if($value->tinhtrang == 1): ?>
                            <td><a href="<?php echo e(route('tinhtrang_capnhat',$value->id)); ?>" class="status-order">Đang xử lý</a></td>
                            <?php else: ?>
                            <td><a href="" class="status-order status-order-success">Giao hàng thành công</a></td>
                            <?php endif; ?>
                            <td>
                                <p><?php echo e($value->created_at); ?></p>
                                <?php echo e($value->created_at->diffForHumans()); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center text-danger">Không có đơn hàng mới!</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaptopStore\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>