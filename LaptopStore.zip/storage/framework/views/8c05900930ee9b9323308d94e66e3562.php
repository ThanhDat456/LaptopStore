
<?php $__env->startSection('title', 'Hoàn tất đặt hàng'); ?>
<?php $__env->startSection('content'); ?>
<div class="container pb-5 mb-sm-4">
    <div class="pt-5">
        <div class="card py-3 mt-sm-3">
            <div class="card-body text-center">
                <h2 class="h4 pb-3">Cảm ơn bạn đã đặt hàng!</h2>
                <p class="fs-sm mb-2">Đơn hàng của bạn đã được đặt và sẽ được xử lý trong thời gian sớm nhất.</p>
                <p class="fs-sm">Bạn sẽ sớm nhận được email xác nhận đơn đặt hàng của bạn.</p>
                <a class="btn btn-danger mt-3 me-3" href="<?php echo e(route('trangchu')); ?>">
                    <i class="ci-cart me-2"></i>Tiếp tục mua hàng
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LaptopStore\resources\views/frontend/dathangthanhcong.blade.php ENDPATH**/ ?>